@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0server\ps\make-shortcut.ps1" -Vbs "%~dp0启动应用集合.vbs"
if errorlevel 1 (
  echo Could not update the desktop shortcut.
) else (
  echo Desktop shortcut updated.
)
pause
