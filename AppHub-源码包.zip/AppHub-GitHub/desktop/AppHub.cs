using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

static class Program
{
    private const string AppTitle = "应用集合";

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern int SetCurrentProcessExplicitAppUserModelID(string appId);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr FindWindow(string className, string windowName);

    [DllImport("user32.dll")]
    private static extern bool ShowWindow(IntPtr hWnd, int command);

    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool SetProcessDpiAwarenessContext(IntPtr value);

    [DllImport("user32.dll")]
    private static extern bool SetProcessDPIAware();

    [DllImport("user32.dll")]
    private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint modifiers, uint virtualKey);

    [DllImport("user32.dll")]
    private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    private static Mutex instanceMutex;

    [STAThread]
    static void Main()
    {
        string appDir = AppContext.BaseDirectory;
        Directory.CreateDirectory(Path.Combine(appDir, "data"));

        try
        {
            SetProcessDpiAwarenessContext(new IntPtr(-4));
        }
        catch
        {
            try { SetProcessDPIAware(); } catch { }
        }

        bool createdNew;
        instanceMutex = new Mutex(true, "AppHub.Launcher.SingleInstance", out createdNew);
        if (!createdNew)
        {
            IntPtr existing = FindWindow(null, AppTitle);
            if (existing != IntPtr.Zero)
            {
                ShowWindow(existing, 9);
                SetForegroundWindow(existing);
            }
            return;
        }

        SetCurrentProcessExplicitAppUserModelID("AppHub.Launcher");

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.ThreadException += delegate(object sender, ThreadExceptionEventArgs e)
        {
            ShowError(appDir, e.Exception);
        };
        AppDomain.CurrentDomain.UnhandledException += delegate(object sender, UnhandledExceptionEventArgs e)
        {
            WriteLog(appDir, "FATAL " + e.ExceptionObject);
        };

        try
        {
            Application.Run(new MainForm(appDir));
        }
        finally
        {
            if (instanceMutex != null)
            {
                try { instanceMutex.ReleaseMutex(); } catch { }
            }
        }
    }

    internal static void WriteLog(string appDir, string message)
    {
        try
        {
            File.AppendAllText(
                Path.Combine(appDir, "data", "desktop.log"),
                DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + " " + message + Environment.NewLine,
                Encoding.UTF8);
        }
        catch { }
    }

    internal static void ShowError(string appDir, Exception error)
    {
        WriteLog(appDir, "ERROR " + error);
        string logPath = Path.Combine(appDir, "data", "desktop.log");
        MessageBox.Show(
            AppTitle + " 启动失败：\n\n" + error.Message + "\n\n详细日志：" + logPath,
            AppTitle,
            MessageBoxButtons.OK,
            MessageBoxIcon.Error);
    }
}

sealed class MainForm : Form
{
    [ComImport]
    [Guid("602D4995-B13A-429b-A66E-1935E44F4317")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface ITaskbarList2
    {
        void HrInit();
        void AddTab(IntPtr hwnd);
        void DeleteTab(IntPtr hwnd);
        void ActivateTab(IntPtr hwnd);
        void SetActiveAlt(IntPtr hwnd);
        void MarkFullscreenWindow(IntPtr hwnd, [MarshalAs(UnmanagedType.Bool)] bool fullscreen);
    }

    [DllImport("user32.dll")]
    private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint modifiers, uint virtualKey);

    [DllImport("user32.dll")]
    private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    private static extern bool ShowWindow(IntPtr hWnd, int command);

    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool SetWindowPos(
        IntPtr hWnd, IntPtr insertAfter, int x, int y, int cx, int cy, uint flags);

    [DllImport("user32.dll")]
    private static extern bool BringWindowToTop(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern void keybd_event(byte virtualKey, byte scan, uint flags, UIntPtr extra);

    private const uint MOD_ALT = 0x0001;
    private const uint MOD_CONTROL = 0x0002;
    private const uint MOD_SHIFT = 0x0004;
    private const uint MOD_WIN = 0x0008;
    private const uint MOD_NOREPEAT = 0x4000;

    private const int HotkeyExit = 1;
    private const int HotkeyFullscreen = 2;
    private const int HotkeyDesktopToggle = 3;

    private readonly string appDir;
    private WebView2 web;
    private SplashOverlay splash;
    private Process serverProcess;
    private int port;
    private bool fullscreen;
    private Rectangle windowedBounds;
    private System.Windows.Forms.Timer taskbarGuardTimer;
    private System.Windows.Forms.Timer hotkeyWatchTimer;
    private int taskbarMarkFailures;
    private string hotkeySpec = "Ctrl+Alt+Space";
    private DateTime hotkeyStamp = DateTime.MinValue;
    private bool hotkeyRegistered;
    private readonly Stopwatch startedAt = Stopwatch.StartNew();

    public MainForm(string appDir)
    {
        this.appDir = appDir;
        Text = "应用集合";
        MinimumSize = new Size(900, 620);
        StartPosition = FormStartPosition.Manual;
        BackColor = Color.FromArgb(8, 10, 18);
        AutoScaleMode = AutoScaleMode.Dpi;
        KeyPreview = true;
        FormBorderStyle = FormBorderStyle.None;

        Rectangle screenBounds = FullscreenBounds(Screen.FromPoint(Cursor.Position));
        int windowWidth = Math.Min(1340, screenBounds.Width);
        int windowHeight = Math.Min(880, screenBounds.Height);
        windowedBounds = new Rectangle(
            screenBounds.Left + Math.Max(0, (screenBounds.Width - windowWidth) / 2),
            screenBounds.Top + Math.Max(0, (screenBounds.Height - windowHeight) / 2),
            windowWidth,
            windowHeight);
        Bounds = screenBounds;
        fullscreen = true;

        string iconPath = Path.Combine(appDir, "assets", "apphub.ico");
        if (File.Exists(iconPath))
        {
            try { Icon = new Icon(iconPath); } catch { }
        }

        splash = new SplashOverlay(appDir);
        splash.Dock = DockStyle.Fill;
        Controls.Add(splash);

        Shown += async delegate
        {
            MarkTaskbarAvailable();
            await StartAsync();
            MarkTaskbarAvailable();
        };
        HandleCreated += delegate
        {
            RegisterHotKey(Handle, 1, 0x0002 | 0x0001, (uint)Keys.Q);
            RegisterHotKey(Handle, 2, 0, 0x7A);
            LoadHotkey();
        };

        taskbarGuardTimer = new System.Windows.Forms.Timer();
        taskbarGuardTimer.Interval = 2000;
        taskbarGuardTimer.Tick += delegate
        {
            if (fullscreen) MarkTaskbarAvailable();
        };
        taskbarGuardTimer.Start();

        hotkeyWatchTimer = new System.Windows.Forms.Timer();
        hotkeyWatchTimer.Interval = 800;
        hotkeyWatchTimer.Tick += delegate { WatchHotkeyFile(); };
        hotkeyWatchTimer.Start();

        FormClosing += delegate { StopServer(); };
        FormClosing += delegate
        {
            try
            {
                UnregisterHotKey(Handle, 1);
                UnregisterHotKey(Handle, 2);
                if (hotkeyRegistered) UnregisterHotKey(Handle, HotkeyDesktopToggle);
            }
            catch { }
            try { taskbarGuardTimer.Stop(); } catch { }
            try { hotkeyWatchTimer.Stop(); } catch { }
            try
            {
                if (web != null)
                {
                    web.Dispose();
                    web = null;
                }
            }
            catch { }
        };
        KeyDown += delegate(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F11)
            {
                ToggleFullscreen();
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        };
    }

    private async Task StartAsync()
    {
        try
        {
            port = GetFreePort();
            StartServer(port);

            Task<bool> webTask = PrepareWebView(null);
            await WaitForServer(port);
            bool webReady = await webTask;

            if (!webReady)
            {
                Program.WriteLog(appDir, "webview retry in compatibility mode");
                DisposeWeb();
                await Task.Delay(150);
                webReady = await PrepareWebView(
                    new CoreWebView2EnvironmentOptions("--no-sandbox --disable-gpu"));
            }
            if (!webReady)
            {
                throw new Exception("WebView2 初始化失败，请确认系统已安装 Microsoft Edge WebView2 运行时。");
            }

            bool pageReady = await NavigateAndWait(port);
            if (!pageReady)
            {
                Program.WriteLog(appDir, "page retry with fresh profile");
                DisposeWeb();
                await Task.Delay(150);
                webReady = await PrepareWebView(
                    new CoreWebView2EnvironmentOptions("--no-sandbox --disable-gpu"),
                    true);
                if (webReady)
                {
                    pageReady = await NavigateAndWait(port);
                }
            }
            if (!pageReady)
            {
                throw new Exception("界面加载失败。");
            }

            if (splash != null && !splash.IsDisposed)
            {
                splash.FadeOut();
            }
            await Task.Delay(380);
            if (web != null)
            {
                web.Visible = true;
            }
            if (splash != null && !splash.IsDisposed)
            {
                splash.Visible = false;
            }
            Program.WriteLog(appDir, "webview ready");
        }
        catch (Exception error)
        {
            Program.WriteLog(appDir, "ERROR " + error);
            if (splash != null && !splash.IsDisposed)
            {
                splash.SetStatus("加载失败，请按 Ctrl+Alt+Q 退出");
                splash.BringToFront();
            }
            else
            {
                MessageBox.Show(
                    "应用集合启动失败：\n\n" + error.Message + "\n\n日志：" + Path.Combine(appDir, "data", "desktop.log"),
                    "应用集合",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }

    protected override void WndProc(ref Message message)
    {
        if (message.Msg == 0x0312)
        {
            int id = message.WParam.ToInt32();
            if (id == 1)
            {
                Close();
                return;
            }
            if (id == 2)
            {
                ToggleFullscreen();
                return;
            }
            if (id == 3)
            {
                ToggleDesktopView();
                return;
            }
        }
        base.WndProc(ref message);
    }

    private int GetFreePort()
    {
        TcpListener listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        int freePort = ((IPEndPoint)listener.LocalEndpoint).Port;
        listener.Stop();
        return freePort;
    }

    private string ResolveNode()
    {
        string[] candidates = new string[]
        {
            @"C:\Program Files\nodejs\node.exe",
            @"C:\Program Files (x86)\nodejs\node.exe"
        };
        foreach (string candidate in candidates)
        {
            if (File.Exists(candidate)) return candidate;
        }
        string pathVariable = Environment.GetEnvironmentVariable("PATH") ?? "";
        foreach (string folder in pathVariable.Split(';'))
        {
            try
            {
                string candidate = Path.Combine(folder.Trim(), "node.exe");
                if (File.Exists(candidate)) return candidate;
            }
            catch { }
        }
        throw new Exception("未找到 Node.js，请先安装 Node.js（https://nodejs.org）。");
    }

    private void StartServer(int serverPort)
    {
        string serverJs = Path.Combine(appDir, "server", "server.js");
        if (!File.Exists(serverJs))
        {
            throw new Exception("缺少 server\\server.js，请保持文件夹结构完整。");
        }

        ProcessStartInfo info = new ProcessStartInfo(ResolveNode(), "\"" + serverJs + "\"");
        info.WorkingDirectory = appDir;
        info.UseShellExecute = false;
        info.CreateNoWindow = true;
        info.RedirectStandardOutput = true;
        info.RedirectStandardError = true;
        info.StandardOutputEncoding = Encoding.UTF8;
        info.StandardErrorEncoding = Encoding.UTF8;
        info.EnvironmentVariables["APPHUB_PORT"] = serverPort.ToString();

        serverProcess = new Process();
        serverProcess.StartInfo = info;
        serverProcess.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e)
        {
            if (!string.IsNullOrEmpty(e.Data)) Program.WriteLog(appDir, "OUT " + e.Data);
        };
        serverProcess.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e)
        {
            if (!string.IsNullOrEmpty(e.Data)) Program.WriteLog(appDir, "ERR " + e.Data);
        };
        serverProcess.Start();
        serverProcess.BeginOutputReadLine();
        serverProcess.BeginErrorReadLine();
        Program.WriteLog(appDir, "server started on port " + serverPort + " pid " + serverProcess.Id);
    }

    private async Task WaitForServer(int serverPort)
    {
        for (int attempt = 0; attempt < 120; attempt++)
        {
            if (serverProcess.HasExited)
            {
                throw new Exception("后台服务已退出（退出码 " + serverProcess.ExitCode + "）。");
            }
            if (await IsServerReady(serverPort)) return;
            await Task.Delay(200);
        }
        throw new Exception("等待后台服务超时。");
    }

    private static async Task<bool> IsServerReady(int serverPort)
    {
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:" + serverPort + "/api/status");
            request.Timeout = 800;
            request.Proxy = null;
            using (HttpWebResponse response = (HttpWebResponse)await request.GetResponseAsync())
            using (StreamReader reader = new StreamReader(response.GetResponseStream()))
            {
                string body = await reader.ReadToEndAsync();
                return body.Contains("\"app\":\"apphub\"");
            }
        }
        catch
        {
            return false;
        }
    }

    private async Task StartWebView(int serverPort)
    {
        string userData = ResolveWebViewDataFolder();
        bool success = await TryStartWebView(serverPort, userData, null);

        if (!success)
        {
            Program.WriteLog(appDir, "webview retry in compatibility mode");
            try
            {
                if (web != null)
                {
                    Controls.Remove(web);
                    web.Dispose();
                    web = null;
                }
            }
            catch { }
            await Task.Delay(500);
            success = await TryStartWebView(
                serverPort,
                userData,
                new CoreWebView2EnvironmentOptions("--no-sandbox --disable-gpu"));
        }

        if (!success)
        {
            throw new Exception("WebView2 页面加载失败，请确认系统已安装 Microsoft Edge WebView2 运行时。");
        }

        long elapsed = startedAt.ElapsedMilliseconds;
        if (elapsed < 1500)
        {
            await Task.Delay((int)(1500 - elapsed));
        }
        if (splash != null && !splash.IsDisposed)
        {
            splash.Visible = false;
        }
        if (web != null)
        {
            web.Visible = true;
        }
        Program.WriteLog(appDir, "webview ready");
    }

    private string ResolveWebViewDataFolder()
    {
        string[] candidates = new string[]
        {
            Path.Combine(
                Path.GetTempPath(),
                "AppHub",
                "WebView2",
                "instance-" + Process.GetCurrentProcess().Id),
            Path.Combine(Path.GetTempPath(), "AppHub", "WebView2-fallback", Guid.NewGuid().ToString("N"))
        };
        foreach (string candidate in candidates)
        {
            try
            {
                Directory.CreateDirectory(candidate);
                return candidate;
            }
            catch { }
        }
        throw new Exception("找不到可写的 WebView2 缓存目录。");
    }

    private async Task<bool> TryStartWebView(
        int serverPort,
        string userData,
        CoreWebView2EnvironmentOptions options)
    {
        WebView2 control = new WebView2();
        control.Dock = DockStyle.Fill;
        control.Visible = false;
        try { control.DefaultBackgroundColor = Color.FromArgb(8, 10, 18); } catch { }
        Controls.Add(control);
        if (splash != null && !splash.IsDisposed)
        {
            splash.BringToFront();
        }
        web = control;

        try
        {
            CoreWebView2Environment environment = await CoreWebView2Environment.CreateAsync(null, userData, options);
            await control.EnsureCoreWebView2Async(environment);

            CoreWebView2Settings settings = control.CoreWebView2.Settings;
            settings.AreDefaultContextMenusEnabled = false;
            settings.AreDevToolsEnabled = false;
            settings.IsStatusBarEnabled = false;
            settings.AreBrowserAcceleratorKeysEnabled = false;
            settings.IsZoomControlEnabled = true;

            control.CoreWebView2.WebMessageReceived += delegate(
                object messageSender,
                CoreWebView2WebMessageReceivedEventArgs messageArgs)
            {
                string message = null;
                try { message = messageArgs.TryGetWebMessageAsString(); } catch { }
                if (message == "toggle-fullscreen")
                {
                    ToggleFullscreen();
                }
                else if (message == "close-app")
                {
                    Close();
                }
            };

            control.CoreWebView2.DocumentTitleChanged += delegate
            {
                if (!string.IsNullOrWhiteSpace(control.CoreWebView2.DocumentTitle))
                {
                    Text = control.CoreWebView2.DocumentTitle;
                }
            };
            control.CoreWebView2.NewWindowRequested += delegate(
                object sender,
                CoreWebView2NewWindowRequestedEventArgs e)
            {
                e.Handled = true;
            };

            TaskCompletionSource<bool> completed = new TaskCompletionSource<bool>();
            control.CoreWebView2.NavigationCompleted += delegate(
                object sender,
                CoreWebView2NavigationCompletedEventArgs e)
            {
                Program.WriteLog(
                    appDir,
                    "navigation completed success=" + e.IsSuccess + " status=" + e.WebErrorStatus);
                if (!completed.Task.IsCompleted)
                {
                    completed.TrySetResult(e.IsSuccess);
                }
            };

            control.Source = new Uri("http://127.0.0.1:" + serverPort + "/");

            Task finished = await Task.WhenAny(completed.Task, Task.Delay(12000));
            if (finished != completed.Task || !completed.Task.Result)
            {
                return false;
            }

            bool pageReady = false;
            for (int attempt = 0; attempt < 12; attempt++)
            {
                try
                {
                    string check = await control.CoreWebView2.ExecuteScriptAsync(
                        "JSON.stringify({ready: document.readyState, tiles: document.querySelectorAll('.tile').length, text: document.body ? document.body.innerText.length : 0})");
                    Program.WriteLog(appDir, "page check " + check);
                    if (!check.Contains("\"tiles\":0") && !check.Contains("\"tiles\": 0"))
                    {
                        pageReady = true;
                        break;
                    }
                }
                catch (Exception checkError)
                {
                    Program.WriteLog(appDir, "page check failed " + checkError.Message);
                }
                await Task.Delay(300);
            }
            if (!pageReady)
            {
                Program.WriteLog(appDir, "page did not render");
                return false;
            }
            return true;
        }
        catch (Exception error)
        {
            Program.WriteLog(appDir, "webview attempt failed " + error.Message);
            return false;
        }
    }

    private string WebViewProfile(bool temporary)
    {
        string profile = temporary
            ? Path.Combine(
                Path.GetTempPath(),
                "AppHub",
                "WebView2",
                "instance-" + Process.GetCurrentProcess().Id + "-" + Guid.NewGuid().ToString("N").Substring(0, 6))
            : Path.Combine(appDir, "data", "webview", "profile");
        Directory.CreateDirectory(profile);
        return profile;
    }

    private async Task<bool> PrepareWebView(
        CoreWebView2EnvironmentOptions options,
        bool forceTemporaryProfile = false)
    {
        string[] profiles;
        if (forceTemporaryProfile)
        {
            profiles = new string[] { WebViewProfile(true) };
        }
        else
        {
            profiles = new string[] { WebViewProfile(false), WebViewProfile(true) };
        }

        foreach (string profile in profiles)
        {
            WebView2 control = null;
            try
            {
                control = new WebView2();
                control.Dock = DockStyle.Fill;
                control.Visible = false;
                try { control.DefaultBackgroundColor = Color.FromArgb(8, 10, 18); } catch { }
                Controls.Add(control);
                if (splash != null && !splash.IsDisposed)
                {
                    splash.BringToFront();
                }
                web = control;

                CoreWebView2Environment environment = await CoreWebView2Environment.CreateAsync(
                    null,
                    profile,
                    options);
                await control.EnsureCoreWebView2Async(environment);

                CoreWebView2Settings settings = control.CoreWebView2.Settings;
                settings.AreDefaultContextMenusEnabled = false;
                settings.AreDevToolsEnabled = false;
                settings.IsStatusBarEnabled = false;
                settings.AreBrowserAcceleratorKeysEnabled = false;
                settings.IsZoomControlEnabled = true;

                control.CoreWebView2.WebMessageReceived += delegate(
                    object messageSender,
                    CoreWebView2WebMessageReceivedEventArgs messageArgs)
                {
                    string message = null;
                    try { message = messageArgs.TryGetWebMessageAsString(); } catch { }
                    if (message == "toggle-fullscreen")
                    {
                        ToggleFullscreen();
                    }
                    else if (message == "close-app")
                    {
                        Close();
                    }
                };

                control.CoreWebView2.DocumentTitleChanged += delegate
                {
                    if (!string.IsNullOrWhiteSpace(control.CoreWebView2.DocumentTitle))
                    {
                        Text = control.CoreWebView2.DocumentTitle;
                    }
                };
                control.CoreWebView2.NewWindowRequested += delegate(
                    object sender,
                    CoreWebView2NewWindowRequestedEventArgs e)
                {
                    e.Handled = true;
                };

                return true;
            }
            catch (Exception error)
            {
                Program.WriteLog(appDir, "webview prepare failed " + profile + " " + error.Message);
                try
                {
                    if (control != null)
                    {
                        Controls.Remove(control);
                        control.Dispose();
                    }
                }
                catch { }
                web = null;
            }
        }
        return false;
    }

    private async Task<bool> NavigateAndWait(int serverPort)
    {
        if (web == null || web.CoreWebView2 == null) return false;

        TaskCompletionSource<bool> completed = new TaskCompletionSource<bool>();
        EventHandler<CoreWebView2NavigationCompletedEventArgs> handler = delegate(
            object sender,
            CoreWebView2NavigationCompletedEventArgs e)
        {
            Program.WriteLog(
                appDir,
                "navigation completed success=" + e.IsSuccess + " status=" + e.WebErrorStatus);
            if (!completed.Task.IsCompleted)
            {
                completed.TrySetResult(e.IsSuccess);
            }
        };

        web.CoreWebView2.NavigationCompleted += handler;
        try
        {
            web.Source = new Uri("http://127.0.0.1:" + serverPort + "/");
            Task finished = await Task.WhenAny(completed.Task, Task.Delay(15000));
            if (finished != completed.Task || !completed.Task.Result)
            {
                return false;
            }

            for (int attempt = 0; attempt < 12; attempt++)
            {
                try
                {
                    string check = await web.CoreWebView2.ExecuteScriptAsync(
                        "JSON.stringify({ready: document.readyState, tiles: document.querySelectorAll('.tile').length, text: document.body ? document.body.innerText.length : 0})");
                    Program.WriteLog(appDir, "page check " + check);
                    if (!check.Contains("\"tiles\":0") && !check.Contains("\"tiles\": 0"))
                    {
                        return true;
                    }
                }
                catch (Exception error)
                {
                    Program.WriteLog(appDir, "page check failed " + error.Message);
                }
                await Task.Delay(250);
            }
            return false;
        }
        finally
        {
            try
            {
                if (web != null && web.CoreWebView2 != null)
                {
                    web.CoreWebView2.NavigationCompleted -= handler;
                }
            }
            catch { }
        }
    }

    private void DisposeWeb()
    {
        try
        {
            if (web != null)
            {
                Controls.Remove(web);
                web.Dispose();
                web = null;
            }
        }
        catch
        {
            web = null;
        }
    }

    private string HotkeyFile
    {
        get { return Path.Combine(appDir, "data", "hotkey.txt"); }
    }

    private void LoadHotkey()
    {
        hotkeyStamp = FileStamp(HotkeyFile);
        string spec = ReadHotkeyFile();
        hotkeySpec = string.IsNullOrEmpty(spec) ? "Ctrl+Alt+Space" : spec;
        ApplyHotkey();
    }

    private void WatchHotkeyFile()
    {
        try
        {
            DateTime stamp = FileStamp(HotkeyFile);
            if (stamp == hotkeyStamp) return;
            hotkeyStamp = stamp;
            string spec = ReadHotkeyFile();
            if (string.IsNullOrEmpty(spec) || spec == hotkeySpec) return;
            hotkeySpec = spec;
            ApplyHotkey();
        }
        catch { }
    }

    private static DateTime FileStamp(string file)
    {
        try
        {
            return File.Exists(file) ? File.GetLastWriteTimeUtc(file) : DateTime.MinValue;
        }
        catch
        {
            return DateTime.MinValue;
        }
    }

    private string ReadHotkeyFile()
    {
        try
        {
            if (!File.Exists(HotkeyFile)) return null;
            string text = File.ReadAllText(HotkeyFile, Encoding.UTF8).Trim();
            return text.Length > 0 && text.Length < 60 ? text : null;
        }
        catch
        {
            return null;
        }
    }

    private void ApplyHotkey()
    {
        if (Handle == IntPtr.Zero) return;
        uint modifiers;
        uint key;
        string spec = hotkeySpec;
        if (!TryParseHotkey(spec, out modifiers, out key))
        {
            spec = "Ctrl+Alt+Space";
            if (!TryParseHotkey(spec, out modifiers, out key)) return;
        }
        if (hotkeyRegistered)
        {
            try { UnregisterHotKey(Handle, HotkeyDesktopToggle); } catch { }
            hotkeyRegistered = false;
        }
        hotkeyRegistered = RegisterHotKey(Handle, HotkeyDesktopToggle, modifiers | MOD_NOREPEAT, key);
        Program.WriteLog(appDir, "hotkey " + spec + " registered=" + hotkeyRegistered);
        try
        {
            if (web != null && web.CoreWebView2 != null)
            {
                web.CoreWebView2.PostWebMessageAsString(
                    "hotkey-status:" + (hotkeyRegistered ? "ok" : "fail") + ":" + spec);
            }
        }
        catch { }
    }

    private static bool TryParseHotkey(string spec, out uint modifiers, out uint key)
    {
        modifiers = 0;
        key = 0;
        if (string.IsNullOrWhiteSpace(spec)) return false;
        string[] parts = spec.Split('+');
        for (int index = 0; index < parts.Length; index++)
        {
            string token = parts[index].Trim();
            if (token.Length == 0) return false;
            if (index == parts.Length - 1)
            {
                key = VirtualKeyFromName(token);
                if (key == 0) return false;
                continue;
            }
            switch (token.ToLowerInvariant())
            {
                case "ctrl":
                case "control":
                    modifiers |= MOD_CONTROL;
                    break;
                case "alt":
                    modifiers |= MOD_ALT;
                    break;
                case "shift":
                    modifiers |= MOD_SHIFT;
                    break;
                case "win":
                case "windows":
                case "meta":
                    modifiers |= MOD_WIN;
                    break;
                default:
                    return false;
            }
        }
        if (key == 0) return false;
        if (modifiers == 0 && !(key >= 0x70 && key <= 0x87) && key != 0x20) return false;
        return true;
    }

    private static uint VirtualKeyFromName(string name)
    {
        if (name.Length == 1)
        {
            char single = char.ToUpperInvariant(name[0]);
            if ((single >= 'A' && single <= 'Z') || (single >= '0' && single <= '9'))
            {
                return (uint)single;
            }
        }
        string lower = name.ToLowerInvariant();
        if (lower.Length >= 2 && lower[0] == 'f')
        {
            int number;
            if (int.TryParse(lower.Substring(1), out number) && number >= 1 && number <= 24)
            {
                return (uint)(0x70 + number - 1);
            }
        }
        switch (lower)
        {
            case "space": return 0x20;
            case "tab": return 0x09;
            case "enter":
            case "return": return 0x0D;
            case "esc":
            case "escape": return 0x1B;
            case "backspace": return 0x08;
            case "delete":
            case "del": return 0x2E;
            case "insert":
            case "ins": return 0x2D;
            case "home": return 0x24;
            case "end": return 0x23;
            case "pageup":
            case "pgup": return 0x21;
            case "pagedown":
            case "pgdn": return 0x22;
            case "up":
            case "arrowup": return 0x26;
            case "down":
            case "arrowdown": return 0x28;
            case "left":
            case "arrowleft": return 0x25;
            case "right":
            case "arrowright": return 0x27;
            case "`":
            case "backquote":
            case "~":
            case "tilde": return 0xC0;
            case "-":
            case "minus": return 0xBD;
            case "=":
            case "equal":
            case "plus": return 0xBB;
            case "[": return 0xDB;
            case "]": return 0xDD;
            case "\\": return 0xDC;
            case ";": return 0xBA;
            case "'": return 0xDE;
            case ",": return 0xBC;
            case ".":
            case "period": return 0xBE;
            case "/": return 0xBF;
        }
        return 0;
    }

    private void ToggleDesktopView()
    {
        bool minimized = WindowState == FormWindowState.Minimized || !Visible;
        bool foreground = GetForegroundWindow() == Handle;
        Program.WriteLog(
            appDir,
            "hotkey toggle state=" + WindowState + " visible=" + Visible + " foreground=" + foreground);
        if (minimized || !foreground)
        {
            ShowLauncherWindow();
        }
        else
        {
            WindowState = FormWindowState.Minimized;
            Program.WriteLog(appDir, "hotkey hide -> state=" + WindowState);
        }
    }

    private void ShowLauncherWindow()
    {
        try
        {
            ShowWindow(Handle, 9);
            if (WindowState == FormWindowState.Minimized)
            {
                WindowState = FormWindowState.Normal;
            }
            ShowWindow(Handle, 5);
            SetWindowPos(Handle, new IntPtr(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040);
            SetWindowPos(Handle, new IntPtr(-2), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040);
            BringWindowToTop(Handle);
            keybd_event(0x12, 0, 0, UIntPtr.Zero);
            keybd_event(0x12, 0, 0x0002, UIntPtr.Zero);
            Activate();
            SetForegroundWindow(Handle);
            if (web != null && web.Visible)
            {
                try { web.Focus(); } catch { }
            }
            Program.WriteLog(
                appDir,
                "hotkey restore -> state=" + WindowState + " foreground=" + (GetForegroundWindow() == Handle));
        }
        catch (Exception error)
        {
            Program.WriteLog(appDir, "restore launcher failed " + error.Message);
        }
    }

    private void ToggleFullscreen()
    {
        if (!fullscreen)
        {
            windowedBounds = Bounds;
            FormBorderStyle = FormBorderStyle.None;
            Bounds = FullscreenBounds(Screen.FromControl(this));
            fullscreen = true;
        }
        else
        {
            FormBorderStyle = FormBorderStyle.Sizable;
            Bounds = windowedBounds;
            fullscreen = false;
        }
        MarkTaskbarAvailable();
    }

    private static Rectangle FullscreenBounds(Screen screen)
    {
        return screen.Bounds;
    }

    private void MarkTaskbarAvailable()
    {
        if (Handle == IntPtr.Zero) return;
        try
        {
            Type taskbarType = Type.GetTypeFromCLSID(
                new Guid("56FDF344-FD6D-11d0-958A-006097C9A090"));
            ITaskbarList2 taskbar = (ITaskbarList2)Activator.CreateInstance(taskbarType);
            taskbar.HrInit();
            taskbar.MarkFullscreenWindow(Handle, false);
            Marshal.ReleaseComObject(taskbar);
            taskbarMarkFailures = 0;
        }
        catch (Exception error)
        {
            taskbarMarkFailures += 1;
            if (taskbarMarkFailures <= 2)
            {
                Program.WriteLog(appDir, "taskbar mark failed " + error.Message);
            }
            if (taskbarMarkFailures >= 3 && taskbarGuardTimer != null)
            {
                taskbarGuardTimer.Stop();
            }
        }
    }

    private void StopServer()
    {
        if (serverProcess == null || serverProcess.HasExited) return;
        try
        {
            ProcessStartInfo info = new ProcessStartInfo(
                "taskkill.exe",
                "/PID " + serverProcess.Id + " /T /F");
            info.CreateNoWindow = true;
            info.UseShellExecute = false;
            Process.Start(info);
        }
        catch
        {
            try { serverProcess.Kill(); } catch { }
        }
    }
}

sealed class SplashOverlay : Control
{
    private readonly Image logo;
    private readonly System.Windows.Forms.Timer timer;
    private float angle;
    private float opacity = 1f;
    private bool fading;
    private string statusText = "正在启动…";
    private readonly Stopwatch introWatch = Stopwatch.StartNew();

    public SplashOverlay(string appDir)
    {
        SetStyle(
            ControlStyles.AllPaintingInWmPaint |
            ControlStyles.OptimizedDoubleBuffer |
            ControlStyles.UserPaint,
            true);
        BackColor = Color.FromArgb(8, 10, 18);

        string logoPath = Path.Combine(appDir, "assets", "apphub.png");
        if (File.Exists(logoPath))
        {
            try { logo = Image.FromFile(logoPath); } catch { }
        }

        timer = new System.Windows.Forms.Timer();
        timer.Interval = 16;
        timer.Tick += delegate
        {
            angle = (angle + 3.4f) % 360f;
            if (fading)
            {
                opacity -= 0.045f;
                if (opacity <= 0f)
                {
                    opacity = 0f;
                    timer.Stop();
                    Visible = false;
                }
            }
            Invalidate();
        };
        timer.Start();
    }

    public void FadeOut()
    {
        fading = true;
    }

    public void SetStatus(string text)
    {
        statusText = text ?? "";
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;

        int width = Width;
        int height = Height;
        int alpha = (int)(255 * opacity);

        using (LinearGradientBrush background = new LinearGradientBrush(
            ClientRectangle,
            Color.FromArgb(alpha, 5, 8, 16),
            Color.FromArgb(alpha, 16, 23, 46),
            90f))
        {
            g.FillRectangle(background, ClientRectangle);
        }

        int centerX = width / 2;
        int logoSize = Math.Max(110, Math.Min(160, height / 7));
        int haloMargin = 30;

        using (Font titleFont = new Font(
            "Microsoft YaHei UI",
            20f,
            FontStyle.Regular,
            GraphicsUnit.Point))
        using (Font statusFont = new Font(
            "Microsoft YaHei UI",
            11f,
            FontStyle.Regular,
            GraphicsUnit.Point))
        using (StringFormat centered = new StringFormat())
        {
            centered.Alignment = StringAlignment.Center;
            SizeF titleSize = g.MeasureString("应用集合", titleFont);
            int titleHeight = (int)Math.Ceiling(titleSize.Height);
            int statusHeight = (int)Math.Ceiling(g.MeasureString(statusText ?? "", statusFont).Height);

            const int gapHaloTitle = 44;
            const int gapTitleStatus = 12;
            int totalHeight =
                logoSize + haloMargin * 2 + gapHaloTitle + titleHeight + gapTitleStatus + statusHeight;
            int top = Math.Max(20, (height - totalHeight) / 2);

            int logoTop = top + haloMargin;
            int logoCenterY = logoTop + logoSize / 2;
            int titleTop = logoTop + logoSize + haloMargin + gapHaloTitle;
            int statusTop = titleTop + titleHeight + gapTitleStatus;

            double introT = Math.Min(1.0, introWatch.Elapsed.TotalMilliseconds / 900.0);
            double ease = 1.0 - Math.Pow(1.0 - introT, 3.0);
            double scale = 0.45 + 0.55 * ease + 0.045 * Math.Sin(Math.PI * introT);
            double rotation = -180.0 * (1.0 - ease);
            double pulse = 0.5 + 0.5 * Math.Sin(introWatch.Elapsed.TotalSeconds * 2.2);

            int glowSize = (int)(logoSize * 1.9);
            using (GraphicsPath glowPath = new GraphicsPath())
            {
                glowPath.AddEllipse(
                    centerX - glowSize / 2,
                    logoCenterY - glowSize / 2,
                    glowSize,
                    glowSize);
                using (PathGradientBrush glow = new PathGradientBrush(glowPath))
                {
                    glow.CenterColor = Color.FromArgb(
                        (int)((45 + 25 * pulse) * opacity),
                        80,
                        130,
                        255);
                    glow.SurroundColors = new Color[] { Color.FromArgb(0, 80, 130, 255) };
                    g.FillPath(glow, glowPath);
                }
            }

            if (logo != null)
            {
                GraphicsState state = g.Save();
                g.TranslateTransform(centerX, logoCenterY);
                g.RotateTransform((float)rotation);
                g.ScaleTransform((float)scale, (float)scale);
                g.DrawImage(
                    logo,
                    new Rectangle(-logoSize / 2, -logoSize / 2, logoSize, logoSize));
                g.Restore(state);
            }

            double haloAlpha = Math.Min(
                1.0,
                Math.Max(0.0, (introWatch.Elapsed.TotalMilliseconds - 180) / 520.0)) * opacity;
            int haloRadius = logoSize / 2 + 18;
            Rectangle haloRect = new Rectangle(
                centerX - haloRadius,
                logoCenterY - haloRadius,
                haloRadius * 2,
                haloRadius * 2);

            using (Pen faintRing = new Pen(
                Color.FromArgb((int)(36 * haloAlpha), 150, 180, 255),
                2f))
            {
                g.DrawEllipse(faintRing, haloRect);
            }
            using (Pen arcPen = new Pen(
                Color.FromArgb((int)(225 * haloAlpha), 110, 160, 255),
                3f))
            {
                arcPen.StartCap = LineCap.Round;
                arcPen.EndCap = LineCap.Round;
                g.DrawArc(arcPen, haloRect, angle, 118f);
            }

            int outerRadius = haloRadius + 10;
            Rectangle outerRect = new Rectangle(
                centerX - outerRadius,
                logoCenterY - outerRadius,
                outerRadius * 2,
                outerRadius * 2);
            using (Pen outerArc = new Pen(
                Color.FromArgb((int)(95 * haloAlpha), 90, 140, 255),
                1.6f))
            {
                outerArc.StartCap = LineCap.Round;
                outerArc.EndCap = LineCap.Round;
                g.DrawArc(outerArc, outerRect, -angle * 1.55f + 70f, 62f);
            }

            double titleT = Math.Min(
                1.0,
                Math.Max(0.0, (introWatch.Elapsed.TotalMilliseconds - 450) / 500.0));
            int titleAlpha = (int)(238 * opacity * titleT);
            float titleOffset = (float)(12 * (1 - titleT));
            using (SolidBrush titleBrush = new SolidBrush(
                Color.FromArgb(titleAlpha, 232, 238, 252)))
            {
                g.DrawString(
                    "应用集合",
                    titleFont,
                    titleBrush,
                    new RectangleF(0, titleTop + titleOffset, width, titleHeight + 2),
                    centered);
            }

            double statusT = Math.Min(
                1.0,
                Math.Max(0.0, (introWatch.Elapsed.TotalMilliseconds - 750) / 450.0));
            if (!string.IsNullOrEmpty(statusText))
            {
                using (SolidBrush statusBrush = new SolidBrush(
                    Color.FromArgb((int)(200 * opacity * statusT), 170, 190, 225)))
                {
                    g.DrawString(
                        statusText,
                        statusFont,
                        statusBrush,
                        new RectangleF(0, statusTop, width, statusHeight + 2),
                        centered);
                }
            }
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            if (timer != null) timer.Dispose();
            if (logo != null) logo.Dispose();
        }
        base.Dispose(disposing);
    }
}

